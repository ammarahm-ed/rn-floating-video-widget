
package com.rnfloatingvideowidget;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.Toast;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.Callback;

public class FloatingVideoWidgetModule extends ReactContextBaseJavaModule {
    private final ReactApplicationContext reactContext;

    public FloatingVideoWidgetModule(ReactApplicationContext reactContext) {
        super(reactContext);
        this.reactContext = reactContext;
    }

    @Override
    public String getName() {
        return "FloatingVideoWidget";
    }

    @ReactMethod
    public void start() {
        Intent service = new Intent(reactContext.getApplicationContext(), FloatingVideoWidgetShowService.class);
        reactContext.startService(service);
    }

    @ReactMethod
    public void openWidget() {
        Intent intent = new Intent("ACTION_OPEN_WIDGET", null, reactContext, FloatingVideoWidgetShowService.class);
        reactContext.startService(intent);
    }

    @ReactMethod
    public void closeWidget() {
        Intent intent = new Intent("ACTION_CLOSE_WIDGET", null, reactContext, FloatingVideoWidgetShowService.class);
        reactContext.startService(intent);
    }

    @ReactMethod
    public void setColor(String color) {
        Integer bgColor = Color.parseColor(String.valueOf(color));
        Intent intent = new Intent("ACTION_SETCOLOR_WIDGET", null, reactContext, FloatingVideoWidgetShowService.class);
        intent.putExtra("COLOR", bgColor);
        reactContext.startService(intent);
    }

    @ReactMethod
    public void setTitle(String title) {

        Intent intent = new Intent("ACTION_SET_TITLE_WIDGET", null, reactContext, FloatingVideoWidgetShowService.class);
        intent.putExtra("TITLE", title);
        reactContext.startService(intent);
    }

    @ReactMethod
    public void setBody(String body) {
        Intent intent = new Intent("ACTION_SET_BODY_WIDGET", null, reactContext, FloatingVideoWidgetShowService.class);
        intent.putExtra("BODY", body);
        reactContext.startService(intent);
    }

    @ReactMethod
    public void setVideo(String url, String seek) {
        Intent intent = new Intent("ACTION_SET_VIDEO", null, reactContext, FloatingVideoWidgetShowService.class);
        intent.putExtra("Seek", seek);
        intent.putExtra("URL", url);

        reactContext.startService(intent);
    }

    @ReactMethod
    public void showToast(String msg) {
        Toast.makeText(reactContext, msg, Toast.LENGTH_LONG).show();
    }

    @ReactMethod
    public void createButton() {
        Intent intent = new Intent("ACTION_CREATE_BUTTON", null, reactContext, FloatingVideoWidgetShowService.class);
        reactContext.startService(intent);
    }
}
