package com.rnfloatingvideowidget;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.IBinder;
import android.graphics.PixelFormat;
import androidx.annotation.Nullable;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.devbrackets.android.exomedia.ui.widget.VideoView;
import android.net.Uri;
import com.facebook.react.ReactApplication;
import com.facebook.react.ReactInstanceManager;
import com.facebook.react.ReactNativeHost;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.example.MainActivity;
import com.rnfloatingvideowidget.R;

import java.util.Date;
import java.util.Random;

public class FloatingVideoWidgetShowService extends Service {

    WindowManager windowManager;
    View floatingView, expandedView, bottomButtons;
    TextView widgetTitle, widgetBody;
    ImageView pauseButton, playButton;
    VideoView imageIcon;
    WindowManager.LayoutParams params;
    ReactContext reactContext = null;

    public FloatingVideoWidgetShowService() {
    }

    private void openWidget() {

        expandedView.setVisibility(View.VISIBLE);
    }

    private void closeWidget() {

        expandedView.setVisibility(View.GONE);
    }

    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

    private void createButton() {

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            switch (intent.getAction()) {
            case "ACTION_OPEN_WIDGET": {

                openWidget();

                break;
            }
            case "ACTION_CLOSE_WIDGET": {
                closeWidget();
                break;
            }
            case "ACTION_SETCOLOR_WIDGET": {
                int newColor = intent.getIntExtra("COLOR", Color.parseColor(String.valueOf("#ffffff")));
                expandedView.setBackgroundColor(newColor);
                break;
            }
            case "ACTION_SET_TITLE_WIDGET": {
                String title = intent.getStringExtra("TITLE");
                widgetTitle.setText(title);
                break;
            }
            case "ACTION_SET_BODY_WIDGET": {
                String body = intent.getStringExtra("BODY");
                widgetBody.setText(body);
                break;
            }
            case "ACTION_SET_VIDEO": {
                String videoUrl = intent.getStringExtra("URL");
                int Seek = Integer.parseInt(intent.getStringExtra("Seek"));

                Uri myUri = Uri.parse(videoUrl);
                imageIcon.setVideoURI(myUri);

                imageIcon.start();

                break;
            }
            case "ACTION_CREATE_BUTTON": {
                createButton();
                break;
            }
            }
        }
        return START_STICKY;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        final ReactInstanceManager reactInstanceManager = getReactNativeHost().getReactInstanceManager();
        ReactContext getReactContext = reactInstanceManager.getCurrentReactContext();
        reactContext = getReactContext;

        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_widget_layout, null);

        params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        assert windowManager != null;
        windowManager.addView(floatingView, params);

        expandedView = floatingView.findViewById(R.id.Layout_Expended);
        bottomButtons = floatingView.findViewById(R.id.app_video_bottom_box);
        imageIcon = (VideoView) floatingView.findViewById(R.id.videoView);
        pauseButton = (ImageView) floatingView.findViewById(R.id.app_video_pause);
        playButton = (ImageView) floatingView.findViewById(R.id.app_video_play);
        floatingView.findViewById(R.id.app_video_crop).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getPackageManager().getLaunchIntentForPackage("com.floatingwidget");
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);

                stopSelf();
            }
        });

        expandedView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                WritableMap args = new Arguments().createMap();

                Random rand = new Random();
                int n = rand.nextInt(50) + 1;
                args.putInt("time", n);
                System.out.println(n);
                sendEvent(reactContext, "eventoTeste", args);

            }
        });

        floatingView.findViewById(R.id.Layout_Expended).setOnTouchListener(new View.OnTouchListener() {
            int X_Axis, Y_Axis;
            float TouchX, TouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                bottomButtons.setVisibility(View.VISIBLE);

                new android.os.Handler().postDelayed(new Runnable() {
                    public void run() {
                        bottomButtons.setVisibility(View.GONE);
                    }
                }, 8000);

                switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    X_Axis = params.x;
                    Y_Axis = params.y;
                    TouchX = event.getRawX();
                    TouchY = event.getRawY();
                    return true;

                case MotionEvent.ACTION_UP:

                    expandedView.setVisibility(View.VISIBLE);
                    return true;

                case MotionEvent.ACTION_MOVE:

                    params.x = X_Axis + (int) (event.getRawX() - TouchX);
                    params.y = Y_Axis + (int) (event.getRawY() - TouchY);
                    windowManager.updateViewLayout(floatingView, params);
                    return true;
                }
                return false;
            }
        });
    }

    private void sendEvent(ReactContext reactContext, String eventName, @Nullable WritableMap params) {
        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(eventName, params);
    }

    public void onPause(View view) {
        playButton.setVisibility(ImageView.VISIBLE);
        pauseButton.setVisibility(ImageView.GONE);

       

        imageIcon.pause();
    }

    public void onResume(View view) {
        playButton.setVisibility(ImageView.GONE);
        pauseButton.setVisibility(ImageView.VISIBLE);

        imageIcon.start();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null)
            windowManager.removeView(floatingView);
    }

    protected ReactNativeHost getReactNativeHost() {
        return ((ReactApplication) getApplication()).getReactNativeHost();
    }

}
